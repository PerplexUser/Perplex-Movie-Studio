TEMPLATE = subdirs
SUBDIRS += audiopanning

